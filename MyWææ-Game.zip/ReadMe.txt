run the MyW��.exe

ignore all other files (do not delite enny of the files)